#! /bin/bash

echo "running python code..."
python source/main.py
python source/question_2.py
