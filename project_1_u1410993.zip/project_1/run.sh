#! /bin/bash

echo "running python code..."
python src/q_1_histogram.py
python src/q_2_thresholding.py
python src/q_3_histogram_equalization.py
