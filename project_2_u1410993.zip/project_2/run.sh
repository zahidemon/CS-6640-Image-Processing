#! /bin/bash

echo "running python code..."
python src/q1_noise.py
python src/q2_linear_filter.py
python src/q3_non_linear_filter.py
